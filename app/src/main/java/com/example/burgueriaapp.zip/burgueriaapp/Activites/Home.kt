package com.example.burgueriaapp.Activites

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.example.burgueriaapp.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

    class Home : AppCompatActivity()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)


        val bfin = findViewById<Button>(R.id.bFinanc)
        bfin.setOnClickListener {
            goFin()
        }

        val bcom = findViewById<Button>(R.id.bCompra)
        bcom.setOnClickListener {
            goComp()
        }

        val bpon = findViewById<Button>(R.id.bPonto)
        bpon.setOnClickListener {
            goPont()
        }

        val btar = findViewById<Button>(R.id.bTarefa)
        btar.setOnClickListener {
            goTar()
        }
        val database = FirebaseDatabase.getInstance()
        val myRef = database.getReference("/")
    }

fun goFin() {
        val gooFin = Intent(this, Financeiro::class.java)

        startActivity(gooFin)
    }

    fun goComp() {
        val gooComp = Intent(this, Compras ::class.java)

        startActivity(gooComp)
    }
    fun goPont() {
        val gooPont = Intent(this, Ponto ::class.java)

        startActivity(gooPont)
    }
    fun goTar() {
        val gooTar = Intent(this, Tarefas ::class.java)

        startActivity(gooTar)
    }

}